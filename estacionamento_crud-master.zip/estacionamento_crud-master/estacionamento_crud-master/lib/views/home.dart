import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../components/menu_inferior.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //drawer: Menu(context),
      appBar: AppBar(
        backgroundColor: Color(0xFFB47BFF),
        title: Text("Estacionamento online =D"),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.asset('assets/imagens/estacionamento.png'),
          ],
        ),
      ),

      bottomNavigationBar: MenuInferior(),
    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';

import '../components/menu_inferior.dart';

import '../controllers/ParkingSpot.dart';
import '../models/ParkingSpot.dart';

InputDecoration _customInputDecoration(String labelText) {
  return InputDecoration(
    labelText: labelText,
    labelStyle: TextStyle(fontSize: 16), //Tamanho da fonte dos campos
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10.0), //Borda arredondada
    ),
    enabledBorder: OutlineInputBorder(
      borderSide: BorderSide(color: Colors.grey), //Cor da borda quando inativo
      borderRadius: BorderRadius.circular(10.0),
    ),
    focusedBorder: OutlineInputBorder(
      borderSide:
          BorderSide(color: Color(0xff761290)), //Cor da borda quando ativo
      borderRadius: BorderRadius.circular(10.0),
    ),
  );
}

class CadastroVaga extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final _formKey = GlobalKey<FormState>();

    final _parkingSpotNumberController = TextEditingController();
    final _licensePlateCarController = TextEditingController();
    final _brandCarController = TextEditingController();
    final _modelCarController = TextEditingController();
    final _colorCarController = TextEditingController();
    final _responsibleNameController = TextEditingController();
    final _apartamentController = TextEditingController();
    final _blockController = TextEditingController();

    var controller = ParkingSpotController.parkingSpotController;

    void handleSubmit() async {
      ParkingSpotModel parkingSpot = ParkingSpotModel(

        "",
        _parkingSpotNumberController.text,
        _licensePlateCarController.text,
        _brandCarController.text,
        _modelCarController.text,

        _colorCarController.text,
        _responsibleNameController.text,
        _apartamentController.text,
        _blockController.text,
      );

      var response =  await controller.post(parkingSpot);

    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Cadastro =D'),
        backgroundColor: Color(0xFFB47BFF),
      ),
      body: CustomScrollView(

        slivers: <Widget>[
          SliverList(
            delegate: SliverChildListDelegate(
              [
                SizedBox(height: 10),
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Form(
                        key: _formKey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[

                            TextFormField(
                              decoration: _customInputDecoration(
                                  'Número da vaga de estacionamento:'),
                              controller: _parkingSpotNumberController,
                            ),

                            SizedBox(height: 30),

                            TextFormField(
                              decoration: _customInputDecoration(
                                  'Placa do veículo:'),
                              controller: _licensePlateCarController,
                            ),

                            SizedBox(height: 30),

                            TextFormField(
                              decoration:
                                  _customInputDecoration('Marca do veículo:'),
                              controller: _brandCarController,
                            ),

                            SizedBox(height: 30),

                            TextFormField(
                              decoration:
                                  _customInputDecoration('Modelo do veículo:'),
                              controller: _modelCarController,
                            ),

                            SizedBox(height: 30),

                            TextFormField(
                              decoration:
                              _customInputDecoration('Cor do cor:'),
                              controller: _colorCarController,
                            ),

                            SizedBox(height: 30),

                            TextFormField(
                              decoration:
                              _customInputDecoration('Nome do responsável:'),
                              controller: _responsibleNameController,
                            ),

                            SizedBox(height: 30),

                            TextFormField(
                              decoration:
                              _customInputDecoration('Apartamento:'),
                              controller: _apartamentController,
                            ),

                            SizedBox(height: 30),

                            TextFormField(
                              decoration:
                              _customInputDecoration('Bloco:'),
                              controller: _blockController,
                            ),

                            SizedBox(height: 30),

                            ElevatedButton(
                          child: Text('Enviar cadastro'),
                          onPressed: handleSubmit,
                        )
                          ],
                        )),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: MenuInferior(),
    );
  }
}

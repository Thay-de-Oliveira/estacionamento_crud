package com.example.estacionamento_crud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
